from collections import OrderedDict,defaultdict
ndict = {1:100,"x":"xxx",2:"A",3:"33"}

ddict = defaultdict(list,{1:100,"x":"xxx",2:"A",3:"33"})  # all keys --> in case key not present no error--> instead specified dt chi default value..


#x = ndict['y']  # normal - y key not present --> keyerror
x = ddict['y'] #  defaultdict --> y key not present--> 0

print(x)

import sys
sys.exit(0)
print(ndict)
print(ddict)


val1 = ndict.setdefault('x',200) #xxx -no changes inside dict      # key-- present --> existing x chi -- > return karel -- xxx
val2 = ndict.setdefault(4,333)   #333 - pair will be added     # key - absent  --> pair(4,333) --> will be added inside dict-->{1:100,"x":"xxx",2:"A",3:"33",4:333} --> returns 333


print(ndict)

import sys
sys.exit(0)


#3.6 --> dict madhe seq preserve --. python 3.6 after --> keys seq maintain --> before no seq--> kind of  set ->
#OrderedDict --> before python 3.6 --> preserve ==> seq preserve --> ordereddict--> dict
# OrderedDict --> deprected --> not in use that much --> all other features are added inside normal dict-->
odict = OrderedDict({1:100,"x":"xxx",2:"A",3:"33"})
print(odict)
odict.move_to_end("x") # 2 key --> pair --> starting la --> start la

print(odict)
import sys
sys.exit(0)
odict.move_to_end(2,last=True) # 2 key --> pair --> ending la
odict.move_to_end(2) # 2 key --> pair --> ending la la




from collections import deque       # double ended queue --> list vr --> both side ne operations -->
nlist = [1,2,3,4,5,6]       # normal list           # append --> appendleft
dlist = deque([1,2,3,4,5,6]) # deque list           # extend --> extendleft
                                                    # pop    --> popleft
                                                    # rotate element by n times-->
            #left la              [0]                     # right hand side la
#deque --> appendleft extendleft popleft        --> append extend pop(index)

dlist.rotate(n=3)   #[4 5 6 1,2,3]          [6 5 1,2,3,4]




from collections import Counter
import random

cnt1 = Counter("Pune")

print(cnt1)

import sys
sys.exit(0)
cnt1 = Counter([1,2,2,2,2,2,2,3,3,3,4,5,1,2,3,7,7,7,7])
cnt2 = Counter([1,2,3,4,5,1,2,4,5,5,5,5,5,6,6])




print('CNT1 :',cnt1)
print('CNT2 :',cnt2)
cnt1.subtract(cnt2)
print("CNT1 :",cnt1)



values =[15, 16, 13, 4, 14, 11, 5, 19, 11, 18, 14, 14, 15, 1, 14, 15, 16, 17, 5, 17, 19, 12, 9, 20, 9, 4, 12, 14, 16, 19, 6, 8, 14, 17, 9, 1, 16, 20, 8, 19, 10, 6, 6, 14, 5, 11, 4, 18, 5, 3]
cnt  = Counter(values)  # to find occureneces --> most_common-- top most pahije astil --> elements --. list madhen number--> no of time iterate karel..

print(cnt)
for item in cnt.elements():
    print(item)

import sys
sys.exit(0)
ans = cnt.most_common(-3)  # 3 top most occurrneces wale number de ->
print(ans)

print(cnt.elements())


import sys
sys.exit(0)

# [random.randint(1,20) for item in range(50)]   # 50 numbers from 1,20 -->
print(values)

for item in set(values): # unique times -->
    print(item,"->",values.count(item))

import sys
sys.exit(0)


from collections import ChainMap

dict1 = {1:1001,2:2001,3:3001,"x":1000}
dict2 = {1:1002,2:2002,3:3002,"y":2000}
dict3 = {1:1003,2:2003,3:3003,"z":3000}

chmap = ChainMap(dict3,dict2,dict1)     # 3,2,1

#chainmap --> lookup -- search - find - without merging dictionaries
    # starts from first --> till found --> returns None --> dict1-->dict2 --> and so on
    # parents --> returns chainmap -- except first dict
    # map --> returns list of dicts -- so that index position dicts --> modify recreate -- chainmap--> any dict modify-->
    # new_child --> adds new pair/dict--> first position --> modification sathi open -->


dict4 = {1:1004,2:2004,3:3004,"a":4000}

chmap = chmap.new_child(dict4)  # 4 3 2 1 -->
print(chmap)

chmap[1] = 4444 # --> dict4-->madhe

print(chmap)
import sys
sys.exit(0)

print('BEFORE : ',chmap)
values  = chmap.maps    #chainmap --> list of dicts --> chainmap --> list of dicts --> format--> index -- list specific dict
values[1][2] = "Xxxx"  # error -->
chmap = ChainMap(values) # double chainmap -->
print('AFTER',chmap)    #
#print(values)
import sys
sys.exit(0)


# dict3 is open for modication

chmap = chmap.parents       # 2,1
#dict2 is open for modification

chmap = chmap.parents       #1
#dict1 is open for modication

# searching all madhe --> first dict--> not found --> second dict --> and so till found --> in case not found --> NONE


print('chainedmap',chmap)
newchamap = chmap.parents  #except first dict --> all other dicts --> automatically dict becomes first --> modification 2nd dict
newchamap.parents

print('newchainmap',newchamap)

import sys
sys.exit(0)

print(chmap)

chmap['z'] =1111

print(chmap)


#dict1.update(dict2)
#dict1.update(dict3)
#print(dict1) # --> {1:1003 2:2003 3:3003 x: 1000 y : 2000 z : 3000} --> data lost here -->


                            # only for search --> from first dict --> till found or last --> none
print(chmap.get(3))      # dict1--> dict2 --> dict3 --> first found --> return value --> not found --> none

chmap['z']="3x"  # # chainedmap -- fktfirst dict -- open for modification --> modifications not allowed in other dict..
print(chmap.get('z'))  #3x

chmap[1]= 2222
print(chmap)
print(chmap)
import sys
sys.exit(0)
from collections import namedtuple      # namedtuple --> provides wrapper to the tuple--> so that we can access tuple value either index or names/property
names = namedtuple('students',["Akashy","Vijay","Yash","Shrwan","Amit"])
students = names(101,102,103,104,105)    # 5 student ids

print(students.Vijay)   # named property
print(students[1])      # index thru

import sys
sys.exit(0)


values = (23,45,78,4,677,89,8,)
print(values[5])

from collections import namedtuple

values = namedtuple('elements',['a','b','c','d','e','f','g'])       # index positions along with names are accessible..
namedt = values(23,45,78,4,677,89,8) # index or thru name-->
print(namedt)
a1,a2,a3,a4,a5,a6,a7 = namedt           # unpacked --> elements from given tuple
print(a2)

print(namedt.f) # it will access to 89 -->
print(namedt[5])