

value = "This is python lang version is 5.23.34 \n"


#file = open(FILE_PATH+'\\emp.txt','a')
#print(file)

#file.close()    # explicitly we need to close

with open(FILE_PATH+'emp.txt','a') as file: # file will be automatically closed
    file.writelines(value)


'''
r   --> read     file shud be present --> else error Filenotfound                                              
w   --> write    always new file  [file exist--> remove old and create new]   
a   --> append    if file exist --> use same file --> file doesnt exist --> create new file                                         
b   --> binary --> Flask --binary data --> audio/video/images --> binary mode                                                      
x   --> just to check file present or absent-- if present- then operations fail-- error


r+      --> read + write        --> file shud be present --> 
w+      --> write + read        --> new file created and u can perform read operation on same file
a+      --> append + read/write     --> read + write + append --> file present nasel -- tr new asel tr --> same use
b+      --> binary read + write


r   --> default mode for open function ->

'''