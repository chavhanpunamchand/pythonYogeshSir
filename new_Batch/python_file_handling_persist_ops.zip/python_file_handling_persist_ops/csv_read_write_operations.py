from python_file_handling_persist_ops.file_service import Service
from python_file_handling_persist_ops.bookinfo import Book,getBook

FILE_PATH = 'D:\\python_work\\payment_gateway_impl\\python_file_handling_persist_ops\\resources\\'
#booklist = [getBook() for item in range(5)]
SEPERATOR = ","
#print(booklist)
def convert_into_book(line):
    line = line.strip()    # remove \n n all
    fields = line.split(SEPERATOR)
    return Book(bkid=fields[0],bknm=fields[1],bkpri=fields[2],bkauth=fields[3])


class CSVOperation(Service):

    def add_new_record(self, book):
        if type(book) == Book:
            allvalues = str(book.bookId) + SEPERATOR + book.bookName + SEPERATOR + str(
                book.bookPrice) + SEPERATOR + book.bookAuthor + "\n"
            with open(FILE_PATH + "bookinfo.csv", 'a') as file:
                file.writelines(allvalues)

    def delete_record(self, bkid):
        records = self.get_all_records()  # 10
        for record in records:
            if record.bookId == bkid:
                # print('book can be removed')
                records.remove(record)
                with open(FILE_PATH + "bookinfo.txt", 'w') as file:
                    for book in records:
                        allvalues = str(book.bookId) + SEPERATOR + book.bookName + SEPERATOR + str(
                            book.bookPrice) + SEPERATOR + book.bookAuthor + "\n"
                        file.writelines(allvalues)
                print('Given Book removed From file')
                return

        print('No book exist with given Id {}'.format(bkid))

    def update_record(self, bkid, book):
        records = self.get_all_records()  # 10
        for record in records:
            if record.bookId == bkid:
                record.bookName = book.bookName
                record.bookPrice = book.bookPrice
                record.bookAuthor = book.bookAuthor
                with open(FILE_PATH + "bookinfo.txt", 'w') as file:
                    for book in records:
                        allvalues = str(book.bookId) + SEPERATOR + book.bookName + SEPERATOR + str(
                            book.bookPrice) + SEPERATOR + book.bookAuthor + "\n"
                        file.writelines(allvalues)
                    print('Book Record Updated..!')
                return
        print('No book with Given Id -- so cannot update...!')

    def get_single_record(self, bkid):
        allbooks = self.get_all_records()
        for book in allbooks:
            if book.bookId == bkid:
                return book
        print('No book with given Id {} exist '.format(bkid))

    def get_all_records(self):
        booklist = []
        with open(FILE_PATH + "bookinfo.txt", 'r') as file:
            alllines = file.readlines()
            for line in alllines:
                book = convert_into_book(line)
                booklist.append(book)
        return booklist

if __name__ == '__main__':
    csvop = CSVOperation()
    book = getBook()
    csvop.add_new_record(book)
