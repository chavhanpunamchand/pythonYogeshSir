from python_file_handling_persist_ops.file_service import Service
import pymysql

class DBOperation(Service):

    def add_new_record(self):
        pass

    def delete_record(self):
        pass

    def update_record(self):
        pass

    def get_single_record(self):
        pass

    def get_all_records(self):
        pass