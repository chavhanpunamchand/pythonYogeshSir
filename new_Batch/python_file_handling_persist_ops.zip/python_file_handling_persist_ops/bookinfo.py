class Book:

    def __init__(self,bkid,bknm,bkpri,bkauth):
        self.bookId = int(bkid)
        self.bookName = bknm
        self.bookPrice = int(bkpri)
        self.bookAuthor = bkauth

    def __str__(self):
        return '''\n Id : {},Name : {}, Price :{}, Author :{}'''.format(self.bookId,self.bookName,self.bookPrice,self.bookAuthor)

    def __repr__(self):
        return str(self)



import random
count = random.randint(1,100)

def getBook():
    global count
    count = count + 1
    return Book(count,'AAAA'+str(count),random.randint(100,900),'Mr. X{}XX'.format(count))



