
from abc import abstractmethod,ABC


class Service(ABC):

    @abstractmethod
    def add_new_record(self):
        pass

    @abstractmethod
    def delete_record(self):
        pass

    @abstractmethod
    def update_record(self):
        pass

    @abstractmethod
    def get_single_record(self):
        pass

    @abstractmethod
    def get_all_records(self):
        pass
