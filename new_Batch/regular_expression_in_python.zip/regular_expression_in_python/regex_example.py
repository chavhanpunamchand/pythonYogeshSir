import re
import time
FILE_PATH = 'C:\\Users\\Lenovo\\Desktop\\sample.txt'
with open(FILE_PATH,'r') as file:
    alllines = file.readlines()
    alllines = [line.strip() for line in alllines]  # end of the line \n \r -> removed
    emailadr = "\\b[\w]+@[\w]+[.][\w]{2,}\\b"
    mobilrptr = "\\b[7-9]{1}[\d]{9}\\b"
    # add ur patterns here ->
    for num,line in enumerate(alllines):
        print('Line num : ',num + 1)
        print(re.findall(emailadr,line))
        print(re.findall(mobilrptr,line))
        print('*'*40)
        time.sleep(2)

'''
5-7 methods
look -<> +ve-ve conditional



'''
import sys
sys.exit(0)

'''

regular expression --> pattern matching..
    --> meta chars --
 a-z A-Z 0-9 _
 \b --> boundry
'''


value = '''The $b45est way fooaaaaa77 xx $33445 566$  to up Yogesh learn 7533445566543 Python abc@gmail.com is by 7533445566 pracYogeshticing examples. 
The page contains 88334455663 examples on basic conce34234pts fooaabaaa of Python. 273 platforms.
You are advised to xxx@yahoo.co.in take the 25xx334455xc55566 references from these fooaaaaa examples 452 and Yogesh_chame@gmail.com try yogesh them 
on your own. 343All the programs on this fooaaaaaa page are tested and should work on YogeshYogesh
all platforms.
'''
import re
values = " abc123  882qprs as288ansd    2892as2334  dasds21455sfsdf78sffs"

followedbydigit = "[a-zA-z]+(?=\d)"     # find all those words --> followed by numbers
followedbychar = "[.]+(?<=\d)"

print(re.findall(followedbychar,values))

middledigit = ""
middlechar = ""

#print(re.findall(startdigit,values))

import sys
sys.exit(0)

# 10 -- digits --> always starts with 789-->
import re

gmailpattern = "[\w]+(?<=gmail\.com)"

print(re.findall(gmailpattern,value))
import sys
sys.exit(0)

print(re.findall('foo(?=[a]{6})', value))
#a = re.match(pattern,value).group(0)
#print(a)
import sys
sys.exit(0)



import sys
sys.exit(0)
mobile_pattern = "\\b[7-9][\d]{9}\\b"

ans = re.findall(mobile_pattern,value)
print(ans)

import sys
sys.exit(0)
namePattern = "\\bYogesh\\b"
print(re.findall(namePattern,value))

import sys
sys.exit(0)


import sys
sys.exit(0)


pattern1 = '[\w]+@[\w]+[.][\w]+[.][\w]+'          #\d --> stands for digit       --> \d or \d+ -- shud be defined somewhere..
pattern2 = '[\w]+@[\w]+[.][\w]+'
pattern3 = f"{pattern1}|{pattern2}"
ans1 = re.findall(pattern3,value)
#ans2 = re.findall(pattern2,value)
print(ans1)
#print(ans2)

'''
\d          only digit              [0-9]                   [^0-9]  [^\d]              \D --> nondigit chars         
\w          all identifiers         [a-zA-Z0-9_]            [^\w]   [^a-zA-Z0-9_]       \W -- Non Identifiers  
\s          white spaces    
'''

'''
name        --> without number and special chars and space --> first letter capital
address     --> list of cities..
pincode     --> 6 digits
salary      --> decimal places
price       --> R or $ 
email       --> 
mobile      -->
landline    --> 020 --> pune asel --> 
uscode      --> social      ()-() -()
pincode/aadhar/pancard/accountnum/accountnumber/creditcard--
password    -->
website
url
port

	will check and let u know..

Lookahead -- LookBehind -->
		+Ve
		-Ve 
		
		conditional -->
(?=...)	Positive lookahead
(?!...)	Negative lookahead
(?<=...)	Positive lookbehind
(?<!...)	Negative lookbehind
(?()|)	Conditional
		



'''


#find out of sum of  -- digits  - numbers

#print(value.isdigit())