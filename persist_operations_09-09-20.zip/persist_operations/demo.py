import openpyxl     # read/write --- excelsheets    -->read/write --> try
import pymysql                                      #--> read-- try out-->

print("hello")

#DATABASE --> WHICH DATABASE ??         MYSQL       ORACLE      POSTGRES
#LIBS     -->                            VENDOR     VENDOR         VENDOR
#

#python -->
#openpyxl       -- python       --> openpyxl LANG MADHECH DEVELOP --> VENDOR..>
#excel          -->  excel wale ???-->VENDOR -->


#laptop --> graphics card --> nvdia --> drivers >>> nvdia --> lm1 lm2 lm3-->


#methods ???


#database --> opertation ---> which database ??