'''
If..elif..else

switch --> thru dict we have implemented this concept--> as there is no default support
in python

'''