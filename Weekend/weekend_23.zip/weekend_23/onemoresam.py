from python_loopings.weekend_23.demo import f1 as demof1
from python_loopings.weekend_23.sample import f1 as samplef1


print(demof1) # 4x
print(samplef1)#1x

demof1() # calls --> function from demo module/file

samplef1() # calls -- function from sample module/file