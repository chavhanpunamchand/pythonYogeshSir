from flask_initial_web_service_demo.accountscontroller import *
from flask_initial_web_service_demo.roomcontroller import *
from flask_initial_web_service_demo.logincontroller import *


if __name__ == '__main__':
    app.run(debug=True)