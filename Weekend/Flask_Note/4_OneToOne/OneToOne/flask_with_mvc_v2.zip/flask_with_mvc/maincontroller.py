from flask_with_mvc import addresscontroller,empcontroller
from flask_with_mvc.config import app

if __name__ == '__main__':
    app.run(debug=True)