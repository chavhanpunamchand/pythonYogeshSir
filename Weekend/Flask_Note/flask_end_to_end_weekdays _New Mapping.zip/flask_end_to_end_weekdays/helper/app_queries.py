#mysql --> default username --> root --> port --> 3306
#postgress - defaultusername ---> postgress   --> 5432

USERNAME = "root"
PASSWORD = "root"
DB_NAME = "flaskdb"
PORT = 3306
HOST = "localhost"

P_USERNAME="postgres"
P_PASSWORD="root"
P_PORT= 5432
P_DB = "flaskdb"
P_HOST="localhost"




PRODUCT_APP_QUERIES = {
    "INSERT" : "",
    "DELETE" : "",
    "UPDATE" : "",
    "FETCH_ONE" : "",
    "FETCH_ALL" : "",
}


# sql knowledege imp --> queries ->
        # orm--> object relational mapping--> framework will write ur queries
#flask-sqlalchemy  --> virtual env --> orm --> object relational mapping

