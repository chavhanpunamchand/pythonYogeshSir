from flask_end_to_end_weekdays.controller.productcontroller import *


if __name__ == '__main__':
    app.run(debug=True,port=5001)