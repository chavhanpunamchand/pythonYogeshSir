from flask import Flask
app = Flask(__name__)       #app configuration

app.template_folder = 'C:\\Users\\Yogesh\\PycharmProjects\\flaskendtoend\\flask_end_to_end_weekdays\\templates'