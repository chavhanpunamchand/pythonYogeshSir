from all_persist_ops.service import EmpService


class EmpDBServiceImpl(EmpService):
    def add_employee(self, emp):
        pass

    def get_employee(self, empid):
        pass

    def get_all_employees(self):
        pass

    def delete_employee(self, empid):
        pass

    def update_employee(self, empid, values):
        pass

    def emp_avg_salary(self):
        pass

    def get_rolebased_avg_salary(self):
        pass

    def get_employees_based_on_role(self, rolenm):
        pass