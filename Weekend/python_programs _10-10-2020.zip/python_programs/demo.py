
#every python file is nothing but -- module -->
            #n variables,functions,methods,class

# will help to the developers-- for faster development-->

num = 1044
Num = 1023
NUM = 1012
nuM = 1202

#method--fun --> def name(params):
                        #--> body-

def addition(num1,num2):
    result = num1 + num2
    print("Ans is --",result)


addition(10,20) #
addition(282,34)#



print('welcome to python coding..!')

#variables --> memory location --> value store

notepad_remarks = 'According US law, you may need Voluntary Product Accessibility Template file for Notepad++ if you are in USA territory.'
notepad_remarks = "According US law, you may need Voluntary Product Accessibility Template file for Notepad++ if you are in USA territory."
notepad_remarks = '''Notepad++ is “Made in Worldwide” and distributed outside of USA territory (both source code and binary) so there shouldn’t be ECCN issue. However you may need Notepad++ ECCN number to conforme to US law, here it is: EAR99

VPAT for Notepad++
According US law, you may need Voluntary Product Accessibility Template file for Notepad++ if you are in USA territory.'''
notepad_remarks = """Notepad++ is “Made in Worldwide” and distributed outside of USA territory (both source code and binary) so there shouldn’t be ECCN issue. However you may need Notepad++ ECCN number to conforme to US law, here it is: EAR99

VPAT for Notepad++
According US law, you may need Voluntary Product Accessibility Template file for Notepad++ if you are in USA territory."""

#Numbers--> python numeric types --> int -- float --> complex
#int
num1 = 10
num2 = 121291839218321738713
num3 = -12971873821
num4 = 1239
num5 = 3

#float
num1 = 1298312.2137172
num1 = 1298312.13

#complex number
num3 = 813921839+2j     # expontial form
num3 = 813921839+2J



# chars -->

name = 'abc'
name = "abc"

#multiline string   --> preserves -- tabs/paragraphase/articles->pages
name = '''abc'''
name = """abc """


#boolean --> true/false

flag = True     # accept/True/present
flag = False    #reject/False/absent

#value absent ->

value = None




'''
    Linux machine configuration --> session --> open point
'''

