#one module --> can have --> n variables--> n functions --. n classes --> n methods

#indetifier --> if someone has given lines of code-- if u are able identify
                #programming elements -->

# variables --> functions --> methods --> class --->


#def --> module --> function    ---> n
#def --> inside class --> method    -> n    --> first of we need class

a = 10  #m level        #variable
b = 20  #m level


def f1():   #m level        -->  function   #function
    print('aaa')    #inside f1
    print('aaa')    #inside f1
    print('aaa')    #inside f1

print('aaa')        #m level --> ya level --> function end

class A:            #m level        #class

    def m1(self):   #inside class   -->method   #method
        print('inside method')

def x(self):        # this function is inside m1 --> which is inside A
    pass











a = 10

def x():
    b = 10
    print('xx') # fun body ends
    x= 10
#sample - is module --> file is nothing in a python -- module

#sample module contains --> what --> variables--> n variables
                                    #functions --> n
num = 10        #variable --> int
name = "yogesh" #variable =? str


abc = 10

def f4():
    pass        # i have nothing to write

def f1():   # functions
    print('inside f1')
    print('inside f1')

def f2():
    print('inside f1')


class ABC:

    def m1(self):   #methods
        pass

    def m2(self):
        pass